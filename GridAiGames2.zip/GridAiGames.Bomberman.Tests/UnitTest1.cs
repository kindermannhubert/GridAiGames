﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GridAiGames.Bomberman.Tests
{
    [TestClass]
    public class UnitTest1
    {
        private class ManualIntelligence : IIntelligence<Player, PlayerAction>
        {
            private readonly Dictionary<Player, PlayerAction> nextActions = new Dictionary<Player, PlayerAction>();

            public IEnumerable<(Player player, PlayerAction action)>
                GetActionForTeam(
                    IReadOnlyGameGrid<Player, PlayerAction> gameGrid,
                    IReadOnlyList<Player> teamPlayers,
                    ulong iteration)
            {
                foreach (var player in teamPlayers)
                {
                    if (nextActions.ContainsKey(player))
                    {
                        yield return (player, nextActions[player]);
                    }
                    else
                    {
                        yield return (player, PlayerAction.None);
                    }
                }
                nextActions.Clear();
            }

            public void SetNextActions(
                IReadOnlyGameGrid<Player, PlayerAction> gameGrid,
                params (string playerName, PlayerAction action)[] actions)
            {
                foreach (var item in actions)
                {
                    var player = gameGrid.AllPlayers.Single(p => p.Name == item.playerName);
                    nextActions.Add(player, item.action);
                }
            }
        }

        private class TestGameGrid : GameGrid
        {
            private ulong iteration;

            public TestGameGrid(
                int width,
                int height,
                IReadOnlyList<TeamDefinition<Player, PlayerAction>> teamDefinitions,
                Dictionary<string, Position> playerPositionsPerName,
                Action<GameGrid> addGameObjects)
                : base(
                      width,
                      height,
                      teamDefinitions,
                      (teamName, playerName) => playerPositionsPerName[playerName],
                      addGameObjects,
                      new Random(1))
            {
            }

            public void Update()
            {
                Update(iteration++);
            }
        }

        [TestMethod]
        public void TestMethod1()
        {
            const string PlayerName = "John";
            var intelligence = new ManualIntelligence();

            var grid = new TestGameGrid(
                10, 10,
                new TeamDefinition<Player, PlayerAction>[]
                {
                    new TeamDefinition<Player, PlayerAction>("Team A", new[] { new PlayerDefinition(PlayerName) }, intelligence)
                },
                new Dictionary<string, Position>() { { PlayerName, new Position(8, 8) } },
                g =>
                {
                    //g.
                });

            var player = grid.AllPlayers.Single(p => p.Name == PlayerName);

            grid.Update();
            Assert.IsTrue(grid.GetPlayers(8, 8).Single() == player);

            intelligence.SetNextActions(grid, (PlayerName, PlayerAction.MoveRight));
            grid.Update();
            Assert.IsFalse(grid.GetPlayers(8, 8).Any());
            Assert.IsTrue(grid.GetPlayers(9, 8).Single() == player);

            intelligence.SetNextActions(grid, (PlayerName, PlayerAction.MoveUp));
            grid.Update();
            Assert.IsFalse(grid.GetPlayers(8, 8).Any());
            Assert.IsFalse(grid.GetPlayers(9, 8).Any());
            Assert.IsTrue(grid.GetPlayers(9, 9).Single() == player);
        }
    }
}
