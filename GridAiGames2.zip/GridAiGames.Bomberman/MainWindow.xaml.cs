﻿using System;
using System.ComponentModel;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using GridAiGames.Bomberman.Gui;

namespace GridAiGames.Bomberman
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private readonly WpfRenderer wpfRenderer;
        private readonly Thread backgroundThread;
        private double gameIteration;
        private bool cancelGame;

        public MainWindow()
        {
            InitializeComponent();

            const int Width = 32;
            const int Height = 32;

            var rand = new Random(1);
            var grid = new GameGrid(
                Width, Height,
                new TeamDefinition<Player, PlayerAction>[]
                {
                    new TeamDefinition<Player, PlayerAction>("Team A", new[] { new PlayerDefinition("Hubert"),/* new PlayerDefinition("Petr")*/ }, new Intelligence()),
                    new TeamDefinition<Player, PlayerAction>("Team B", new[] { new PlayerDefinition("Lojza"), /*new PlayerDefinition("Adam")*/ }, new Intelligence())
                },
                (teamDef, playerDef) => new Position(rand.Next(1, Width - 1), rand.Next(1, Height - 1)),
                AddObjectsToGameGrid,
                rand);

            //var consoleRenderer = new ConsoleRenderer(grid);
            wpfRenderer = new WpfRenderer(grid);

            backgroundThread = new Thread(() =>
                {
                    ulong iteration = 0;
                    const double UpdatingIntervalMs = 3000;
                    const int RenderFramesBetweenUpdate = 10;

                    while (!cancelGame)
                    {
                        grid.Update(iteration);

                        var currentTeamsCount = grid.AllPlayers.Select(p => p.TeamName).Distinct().Count();
                        if (currentTeamsCount < 2)
                        {
                            if (currentTeamsCount == 0)
                            {
                                Console.WriteLine("Nobody wins.");
                                break;
                            }
                            if (currentTeamsCount == 1)
                            {
                                Console.WriteLine($"Team '{grid.AllPlayers}' won.");
                                break;
                            }
                        }

                        gameIteration = iteration;
                        for (int i = 0; i < RenderFramesBetweenUpdate; i++)
                        {
                            gameIteration = iteration + (double)i / RenderFramesBetweenUpdate;
                            //consoleRenderer.Render();
                            try
                            {
                                Dispatcher.Invoke(InvalidateVisual);
                            }
                            catch (TaskCanceledException)
                            {
                                break;
                            }
                            Thread.Sleep(TimeSpan.FromMilliseconds(UpdatingIntervalMs / RenderFramesBetweenUpdate));
                        }

                        iteration++;
                    }
                });
            backgroundThread.Start();
        }

        protected override void OnRender(DrawingContext drawingContext)
        {
            base.OnRender(drawingContext);
            wpfRenderer.Render(drawingContext, ((Panel)Content).ActualWidth, ((Panel)Content).ActualHeight, gameIteration);
        }

        protected override void OnClosing(CancelEventArgs e)
        {
            cancelGame = true;
            backgroundThread.Join(500);

            base.OnClosing(e);
        }

        private static void AddObjectsToGameGrid(GameGrid grid)
        {
            //borders
            for (int x = 0; x < grid.Width; x++)
            {
                grid.AddObject(new Wall(new Position(x, 0)), x, 0);
                grid.AddObject(new Wall(new Position(x, grid.Height - 1)), x, grid.Height - 1);
            }
            for (int y = 1; y < grid.Height - 1; y++)
            {
                grid.AddObject(new Wall(new Position(0, y)), 0, y);
                grid.AddObject(new Wall(new Position(grid.Width - 1, y)), grid.Width - 1, y);
            }

            //for (int i = 0; i < 200; i++)
            //{
            //    var pos = new Position(rand.Next(Width), rand.Next(Height));
            //    AddObject(new Wall(pos, isDestroyable: rand.NextDouble() > 0.5), pos.X, pos.Y);
            //}
            for (int y = 1; y < grid.Height - 1; y++)
                for (int x = 1; x < grid.Width - 1; x++)
                {
                    //if (grid.Random.NextDouble() > 0.5)
                    //{
                    //    var isDestroyable = grid.Random.NextDouble() < 0.5;
                    //    if (isDestroyable /*&& rand.NextDouble() < 0.3*/)
                    //    {
                    //        grid.AddObject(new Bonus(new Position(x, y), (BonusType)grid.Random.Next((int)BonusType._MaxValue + 1)), x, y);
                    //    }
                    //    grid.AddObject(new Wall(new Position(x, y), isDestroyable), x, y);
                    //}
                }
            //AddObject(new Bomb(new Position(0, 0), 3), 0, 0);
        }
    }
}
