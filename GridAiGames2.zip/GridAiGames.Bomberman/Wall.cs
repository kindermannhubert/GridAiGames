﻿namespace GridAiGames.Bomberman
{
    internal class Wall : IGameObject<Player, PlayerAction>
    {
        public Position Position { get; set; }
        public bool IsDestroyable { get; }

        public Wall(Position position, bool isDestroyable = false)
        {
            Position = position;
            this.IsDestroyable = isDestroyable;
        }

        public void Update(IGameGrid<Player, PlayerAction> gameGrid, ulong iteration)
        {
        }
    }
}