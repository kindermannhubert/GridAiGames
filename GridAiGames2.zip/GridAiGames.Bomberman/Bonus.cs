﻿namespace GridAiGames.Bomberman
{
    internal class Bonus : IGameObject<Player, PlayerAction>
    {
        public BonusType Type { get; }
        public Position Position { get; set; }

        public Bonus(Position position, BonusType type)
        {
            Position = position;
            Type = type;
        }

        public void Update(IGameGrid<Player, PlayerAction> gameGrid, ulong iteration)
        {
        }
    }

    public enum BonusType
    {
        Bomb,
        Fire,

        _MaxValue = Fire
    }
}
