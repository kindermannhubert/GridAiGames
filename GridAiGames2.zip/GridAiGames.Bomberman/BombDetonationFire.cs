﻿namespace GridAiGames.Bomberman
{
    internal class BombDetonationFire : IGameObject<Player, PlayerAction>
    {
        private int DisappearAfter;
        private bool isBurning;

        public Position Position { get; set; }
        public bool IsBurning => isBurning;
        public BombDetonationFireType Type { get; }

        public BombDetonationFire(BombDetonationFireType type)
        {
            DisappearAfter = 2;
            isBurning = true;
            Type = type;
        }

        public void Update(IGameGrid<Player, PlayerAction> gameGrid, ulong iteration)
        {
            isBurning = false;

            if (--DisappearAfter == 0)
            {
                gameGrid.RemoveObject(this, Position);
            }
        }
    }

    internal enum BombDetonationFireType
    {
        Horizontal,
        Vertical,
        Center
    }
}
