﻿using System;

namespace GridAiGames.Bomberman
{
    internal class Player : Player<Player, PlayerAction>
    {
        public int MaxPossibleNumberOfBombs { get; set; }
        public int AvailableBombs { get; set; }
        public int BombsFireRadius { get; set; }

        public Player(string name, string teamName, Position position)
            : base(name, teamName, position)
        {
        }

        public void ConsumeBonus(Bonus bonus)
        {
            switch (bonus.Type)
            {
                case BonusType.Bomb:
                    MaxPossibleNumberOfBombs++;
                    break;
                case BonusType.Fire:
                    BombsFireRadius++;
                    break;
                default:
                    throw new InvalidOperationException($"Unknown bonus type: '{bonus.Type}'.");
            }
        }
    }
}