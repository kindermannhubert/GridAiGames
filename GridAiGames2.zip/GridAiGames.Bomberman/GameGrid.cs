﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace GridAiGames.Bomberman
{
    internal class GameGrid : GameGrid<Player, PlayerAction>
    {
        public Random Random { get; }

        public GameGrid(
            int width,
            int height,
            IReadOnlyList<TeamDefinition<Player, PlayerAction>> teamDefinitions,
            Func<string, string, Position> getPlayerPosition,
            Action<GameGrid> addGameObjects,
            Random rand)
            : base(
                  width, height,
                  teamDefinitions,
                  (PlayerDefinition playerDefinition, string teamName) => new Player(playerDefinition.Name, teamName, getPlayerPosition(teamName, playerDefinition.Name)))
        {
            Random = rand;
            addGameObjects(this);

            Initialized = true;
        }

        protected override void ProcessPlayerAction(Player player, PlayerAction action)
        {
            switch (action)
            {
                case PlayerAction.None:
                    break;
                case PlayerAction.MoveLeft:
                    {
                        var newPos = player.Position.Left;
                        if (player.Position.X > 0 && IsPositionAvailableForPlayer(newPos))
                        {
                            MoveObject(player, player.Position, newPos);
                        }
                    }
                    break;
                case PlayerAction.MoveUp:
                    {
                        var newPos = player.Position.Up;
                        if (player.Position.Y < Height - 1 && IsPositionAvailableForPlayer(newPos))
                        {
                            MoveObject(player, player.Position, newPos);
                        }
                    }
                    break;
                case PlayerAction.MoveRight:
                    {
                        var newPos = player.Position.Right;
                        if (player.Position.X < Width - 1 && IsPositionAvailableForPlayer(newPos))
                        {
                            MoveObject(player, player.Position, newPos);
                        }
                    }
                    break;
                case PlayerAction.MoveDown:
                    {
                        var newPos = player.Position.Down;
                        if (player.Position.X > 0 && IsPositionAvailableForPlayer(newPos))
                        {
                            MoveObject(player, player.Position, newPos);
                        }
                    }
                    break;
                case PlayerAction.PlaceBomb:
                    if (IsPositionAvailableForBomb(player.Position))
                    {
                        this.AddObject(new Bomb(player.Position, 3), player.Position);
                    }
                    break;
                default:
                    throw new InvalidOperationException($"Unknown player's action: '{action}'.");
            }
        }

        public override bool ConsolidateNewObjectsAndPlayers()
        {
            bool reconsolidationNeeded = false;

            var objectList = new List<IGameObject<Player, PlayerAction>>();
            for (int y = 0; y < Height; y++)
                for (int x = 0; x < Width; x++)
                {
                    var objects = GetObjects(x, y);
                    if (objects.Any(o => o is BombDetonationFire f && f.IsBurning))
                    {
                        //kill players
                        foreach (var player in GetPlayers(x, y))
                        {
                            player.Kill();
                        }

                        //burn destroyable walls
                        bool anyWallDestroyed = false;
                        objectList.Clear();
                        objectList.AddRange(objects.Where(o => o is Wall w && w.IsDestroyable));
                        foreach (var wall in objectList)
                        {
                            Debug.Assert(wall.Position == new Position(x, y));
                            this.RemoveObject(wall, wall.Position);
                            anyWallDestroyed = true;
                        }

                        //burn bonuses
                        if (!anyWallDestroyed) //walls protect bonuses
                        {
                            objectList.Clear();
                            objectList.AddRange(objects.OfType<Bonus>());
                            foreach (var bonus in objectList)
                            {
                                Debug.Assert(bonus.Position == new Position(x, y));
                                this.RemoveObject(bonus, bonus.Position);
                            }
                        }

                        //detonate other bombs
                        objectList.Clear();
                        objectList.AddRange(objects.OfType<Bomb>());
                        foreach (Bomb bomb in objectList)
                        {
                            Debug.Assert(bomb.Position == new Position(x, y));
                            bomb.Detonate(this);
                            reconsolidationNeeded = true;
                        }
                    }

                    objectList.Clear();
                    objectList.AddRange(objects.OfType<Bonus>());
                    foreach (Bonus bonus in objectList)
                    {
                        var eatenByPlayer = false;
                        foreach (var player in GetPlayers(x, y))
                        {
                            //everyone gets the bonus
                            player.ConsumeBonus(bonus);
                            eatenByPlayer = true;
                        }
                        if (eatenByPlayer) this.RemoveObject(bonus, bonus.Position);
                    }
                }

            return reconsolidationNeeded;
        }

        private bool IsPositionAvailableForPlayer(Position position)
        {
            foreach (var obj in GetObjects(position))
            {
                switch (obj)
                {
                    case Wall _:
                        return false;
                    case Bomb _:
                    case BombDetonationFire _:
                    case Bonus _:
                        break;
                    default:
                        throw new InvalidOperationException($"Unknown object type: '{obj.GetType().FullName}'.");
                }
            }
            return true;
        }

        private bool IsPositionAvailableForBomb(Position position)
        {
            foreach (var obj in GetObjects(position))
            {
                switch (obj)
                {
                    case Wall _:
                    case Bomb _:
                        return false;
                    case BombDetonationFire _:
                    case Bonus _:
                        break;
                    default:
                        throw new InvalidOperationException($"Unknown object type: '{obj.GetType().FullName}'.");
                }
            }
            return true;
        }
    }
}