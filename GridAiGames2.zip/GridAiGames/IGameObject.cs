﻿namespace GridAiGames
{
    public interface IGameObject<PlayerType, PlayerActionType>
        where PlayerType : Player<PlayerType, PlayerActionType>
    {
        Position Position { get; set; }
        void Update(IGameGrid<PlayerType, PlayerActionType> gameGrid, ulong iteration);
    }
}