﻿using System.Collections.Generic;

namespace GridAiGames
{
    public interface IIntelligence<PlayerType, PlayerActionType>
        where PlayerType : Player<PlayerType, PlayerActionType>
    {
        IEnumerable<(PlayerType player, PlayerActionType action)>
            GetActionForTeam(
            IReadOnlyGameGrid<PlayerType, PlayerActionType> gameGrid,
            IReadOnlyList<PlayerType> teamPlayers,
            ulong iteration);
    }
}