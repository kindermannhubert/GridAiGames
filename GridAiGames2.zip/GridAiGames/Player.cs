﻿namespace GridAiGames
{
    public abstract class Player<PlayerType, PlayerActionType> : IGameObject<PlayerType, PlayerActionType>
        where PlayerType : Player<PlayerType, PlayerActionType>
    {
        private Position previousPosition;
        private bool isDead;

        public Position Position { get; set; }
        public Position PreviousPosition => previousPosition;
        public string Name { get; }
        public string TeamName { get; }

        protected Player(string name, string teamName, Position position)
        {
            Name = name;
            TeamName = teamName;
            Position = previousPosition = position;
        }

        public virtual void Update(IGameGrid<PlayerType, PlayerActionType> gameGrid, ulong iteration)
        {
            previousPosition = Position;

            if (isDead) gameGrid.PlayerDied((PlayerType)this);
        }

        public void Kill()
        {
            isDead = true;
        }
    }
}