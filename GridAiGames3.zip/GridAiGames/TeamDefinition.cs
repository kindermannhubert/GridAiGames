﻿using System.Collections.Generic;

namespace GridAiGames
{
    public class TeamDefinition<PlayerType, PlayerActionType, PlayerStateType>
        where PlayerType : Player<PlayerType, PlayerActionType, PlayerStateType>
        where PlayerStateType : struct, IGameObjectState<PlayerStateType>
    {
        public string Name { get; }
        public IReadOnlyList<PlayerDefinition> Players { get; }
        public IIntelligence<PlayerType, PlayerActionType, PlayerStateType> Intelligence { get; }

        public TeamDefinition(string name, IReadOnlyList<PlayerDefinition> players, IIntelligence<PlayerType, PlayerActionType, PlayerStateType> intelligence)
        {
            Name = name;
            Players = players;
            Intelligence = intelligence;
        }
    }
}