﻿namespace GridAiGames
{
    public interface IGameGrid<PlayerType, PlayerActionType, PlayerStateType> : IReadOnlyGameGrid<PlayerType, PlayerActionType, PlayerStateType>
        where PlayerType : Player<PlayerType, PlayerActionType, PlayerStateType>
        where PlayerStateType : struct, IGameObjectState<PlayerStateType>
    {
        void AddObject(GameObject<PlayerType, PlayerActionType, PlayerStateType> obj);
        void RemoveObject(GameObject<PlayerType, PlayerActionType, PlayerStateType> obj);
        void PlayerDied(PlayerType player);
    }
}