﻿namespace GridAiGames
{
    public interface IGameObjectState<T>
        where T : struct
    {
        Position Position { get; set; }
    }
}
