﻿namespace GridAiGames
{
    public abstract class GameObject<PlayerType, PlayerActionType, PlayerStateType, ObjectStateType> : GameObject<PlayerType, PlayerActionType, PlayerStateType>
        where PlayerType : Player<PlayerType, PlayerActionType, PlayerStateType>
        where PlayerStateType : struct, IGameObjectState<PlayerStateType>
        where ObjectStateType : struct, IGameObjectState<ObjectStateType>
    {
        protected ObjectStateType state;
        private ObjectStateType savedState;

        public sealed override Position Position
        {
            get => state.Position;
            internal set => state.Position = value;
        }

        public GameObject(Position position)
        {
            state.Position = position;
        }

        internal sealed override void SaveState()
        {
            savedState = state;
        }

        internal sealed override void SwitchCurrentAndSavedState()
        {
            Utils.Exchange(ref state, ref savedState);
        }
    }

    public abstract class GameObject<PlayerType, PlayerActionType, PlayerStateType>
        where PlayerType : Player<PlayerType, PlayerActionType, PlayerStateType>
        where PlayerStateType : struct, IGameObjectState<PlayerStateType>
    {
        public abstract Position Position { get; internal set; }

        /// <summary>
        /// Should not affect other object states.
        /// </summary>
        public abstract void Update(IGameGrid<PlayerType, PlayerActionType, PlayerStateType> gameGrid, ulong iteration);

        internal abstract void SaveState();
        internal abstract void SwitchCurrentAndSavedState();
    }
}