﻿namespace GridAiGames
{
    public class PlayerDefinition
    {
        public PlayerDefinition(string name)
        {
            Name = name;
        }

        public string Name { get; }
    }
}
