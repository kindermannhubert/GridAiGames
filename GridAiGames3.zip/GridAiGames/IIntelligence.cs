﻿using System.Collections.Generic;

namespace GridAiGames
{
    public interface IIntelligence<PlayerType, PlayerActionType, PlayerStateType>
        where PlayerType : Player<PlayerType, PlayerActionType, PlayerStateType>
        where PlayerStateType : struct, IGameObjectState<PlayerStateType>
    {
        IEnumerable<(PlayerType player, PlayerActionType action)>
            GetActionForTeam(
            IReadOnlyGameGrid<PlayerType, PlayerActionType, PlayerStateType> gameGrid,
            IReadOnlyList<PlayerType> teamPlayers,
            ulong iteration);
    }
}