﻿namespace GridAiGames
{
    public abstract class Player<PlayerType, PlayerActionType, PlayerStateType> : GameObject<PlayerType, PlayerActionType, PlayerStateType, PlayerStateType>
        where PlayerType : Player<PlayerType, PlayerActionType, PlayerStateType>
        where PlayerStateType : struct, IGameObjectState<PlayerStateType>
    {
        private Position previousPosition;
        private bool isDead;

        public Position PreviousPosition => previousPosition;
        public string Name { get; }
        public string TeamName { get; }

        protected Player(string name, string teamName, Position position)
            : base(position)
        {
            Name = name;
            TeamName = teamName;
            previousPosition = position;
        }

        public override void Update(IGameGrid<PlayerType, PlayerActionType, PlayerStateType> gameGrid, ulong iteration)
        {
            previousPosition = Position;

            if (isDead) gameGrid.PlayerDied((PlayerType)this);
        }

        public void Kill()
        {
            isDead = true;
        }
    }
}