﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace GridAiGames
{
    public abstract class GameGrid<PlayerType, PlayerActionType, PlayerStateType> : IGameGrid<PlayerType, PlayerActionType, PlayerStateType>
        where PlayerType : Player<PlayerType, PlayerActionType, PlayerStateType>
        where PlayerStateType : struct, IGameObjectState<PlayerStateType>
    {
        private readonly IReadOnlyList<TeamDefinition<PlayerType, PlayerActionType, PlayerStateType>> teamDefinitions;
        private readonly Dictionary<string, List<PlayerType>> playersPerTeamName = new Dictionary<string, List<PlayerType>>();
        private readonly List<List<(PlayerType player, PlayerActionType action)>> actionsPerTeam = new List<List<(PlayerType player, PlayerActionType action)>>();

        private List<GameObject<PlayerType, PlayerActionType, PlayerStateType>>[,] currentObjects;
        private List<PlayerType>[,] currentPlayers;

        private List<GameObject<PlayerType, PlayerActionType, PlayerStateType>>[,] newObjects;
        private List<PlayerType>[,] newPlayers;

        private bool consolidationOfNewObjects;

        private bool initialized;
        protected bool Initialized
        {
            get { return initialized; }
            set
            {
                Debug.Assert(value, "Can be set only to true.");
                initialized = value;

                for (int y = 0; y < Height; y++)
                    for (int x = 0; x < Width; x++)
                    {
                        newObjects[x, y].Clear();
                        newObjects[x, y].AddRange(currentObjects[x, y]);

                        newPlayers[x, y].Clear();
                        newPlayers[x, y].AddRange(currentPlayers[x, y]);
                    }
            }
        }

        public IEnumerable<GameObject<PlayerType, PlayerActionType, PlayerStateType>> AllObjects
        {
            get
            {
                for (int y = 0; y < Height; y++)
                    for (int x = 0; x < Width; x++)
                        foreach (var obj in (initialized & consolidationOfNewObjects ? newObjects : currentObjects)[x, y])
                        {
                            yield return obj;
                        }
            }
        }

        public IEnumerable<PlayerType> AllPlayers
        {
            get
            {
                for (int y = 0; y < Height; y++)
                    for (int x = 0; x < Width; x++)
                        foreach (var p in (initialized & consolidationOfNewObjects ? newPlayers : currentPlayers)[x, y])
                        {
                            yield return p;
                        }
            }
        }

        public IReadOnlyList<GameObject<PlayerType, PlayerActionType, PlayerStateType>> GetObjects(Position position) => GetObjects(position.X, position.Y);
        public IReadOnlyList<GameObject<PlayerType, PlayerActionType, PlayerStateType>> GetObjects(int x, int y) => (initialized & consolidationOfNewObjects ? newObjects : currentObjects)[x, y];

        public IReadOnlyList<PlayerType> GetPlayers(Position position) => GetPlayers(position.X, position.Y);
        public IReadOnlyList<PlayerType> GetPlayers(int x, int y) => (initialized & consolidationOfNewObjects ? newPlayers : currentPlayers)[x, y];

        public int Width { get; }
        public int Height { get; }

        public GameGrid(
            int width,
            int height,
            IReadOnlyList<TeamDefinition<PlayerType, PlayerActionType, PlayerStateType>> teamDefinitions,
            CreatePlayerHandler createPlayer)
        {
            Width = width;
            Height = height;
            this.teamDefinitions = teamDefinitions;

            currentObjects = new List<GameObject<PlayerType, PlayerActionType, PlayerStateType>>[width, height];
            newObjects = new List<GameObject<PlayerType, PlayerActionType, PlayerStateType>>[width, height];
            currentPlayers = new List<PlayerType>[width, height];
            newPlayers = new List<PlayerType>[width, height];
            for (int y = 0; y < Height; y++)
                for (int x = 0; x < Width; x++)
                {
                    currentObjects[x, y] = new List<GameObject<PlayerType, PlayerActionType, PlayerStateType>>();
                    newObjects[x, y] = new List<GameObject<PlayerType, PlayerActionType, PlayerStateType>>();
                    currentPlayers[x, y] = new List<PlayerType>();
                    newPlayers[x, y] = new List<PlayerType>();
                }

            if (teamDefinitions.Select(t => t.Name).Distinct().Count() != teamDefinitions.Count)
                throw new InvalidOperationException("All team names must be distinct.");

            foreach (var teamDefinition in teamDefinitions)
            {
                if (teamDefinition.Players.Select(p => p.Name).Distinct().Count() != teamDefinition.Players.Count)
                    throw new InvalidOperationException("All player names must be distinct.");

                foreach (var playerDefinition in teamDefinition.Players)
                {
                    var player = createPlayer(playerDefinition, teamDefinition.Name);
                    AddPlayer(player);

                    if (!playersPerTeamName.TryGetValue(teamDefinition.Name, out var teamPlayers))
                    {
                        playersPerTeamName.Add(teamDefinition.Name, teamPlayers = new List<PlayerType>());
                    }
                    teamPlayers.Add(player);
                }
            }
        }

        public virtual void Update(ulong iteration)
        {
            if (!initialized) throw new InvalidOperationException("Grid should not be updated until its initialized flag is set to true.");

            for (int y = 0; y < Height; y++)
                for (int x = 0; x < Width; x++)
                {
                    newObjects[x, y].Clear();
                    newObjects[x, y].AddRange(currentObjects[x, y]);

                    newPlayers[x, y].Clear();
                    newPlayers[x, y].AddRange(currentPlayers[x, y]);
                }

            CheckPositionsConsistency();

            actionsPerTeam.Clear();
            foreach (var team in teamDefinitions)
            {
                actionsPerTeam.Add(team.Intelligence.GetActionForTeam(this, playersPerTeamName[team.Name], iteration).ToList());
            }

            //team intelligences have to see 'before update' state of objects so we save states before
            for (int y = 0; y < Height; y++)
                for (int x = 0; x < Width; x++)
                {
                    //foreach (var obj in currentObjects[x, y])
                    //{
                    //    obj.SaveState();
                    //}
                    //foreach (var player in currentPlayers[x, y])
                    //{
                    //    player.SaveState();
                    //}
                }

            for (int y = 0; y < Height; y++)
                for (int x = 0; x < Width; x++)
                {
                    foreach (var obj in currentObjects[x, y])
                    {
                        //objects are allowed to change their position in their update method
                        var positionBeforeUpdate = new Position(x, y);
                        obj.Update(this, iteration);
                        if (positionBeforeUpdate != obj.Position)
                        {
                            MoveObject(obj, positionBeforeUpdate, obj.Position);
                        }
                    }

                    foreach (var player in currentPlayers[x, y])
                    {
                        var positionBeforeUpdate = new Position(x, y);
                        player.Update(this, iteration);
                        if (positionBeforeUpdate != player.Position) throw new InvalidOperationException("Player's position can be changed only by IIntelligence actions.");
                    }
                }

            //team intelligences have to see 'before update' state of objects so we switch to before update states
            for (int y = 0; y < Height; y++)
                for (int x = 0; x < Width; x++)
                {
                    //foreach (var obj in currentObjects[x, y])
                    //{
                    //    obj.SwitchCurrentAndSavedState();
                    //}
                    //foreach (var player in currentPlayers[x, y])
                    //{
                    //    player.SwitchCurrentAndSavedState();
                    //}
                }

            CheckPositionsConsistency();
            foreach (var teamActions in actionsPerTeam)
            {
                foreach (var item in teamActions)
                {
                    //player needs to update new self state
                    //item.player.SwitchCurrentAndSavedState();
                    ProcessPlayerAction(item.player, item.action);
                    //switch back to old state so other players see the old one
                    //item.player.SwitchCurrentAndSavedState();
                }
            }
            CheckPositionsConsistency();

            //team intelligences are done so we switch back to new states of objects
            for (int y = 0; y < Height; y++)
                for (int x = 0; x < Width; x++)
                {
                    //foreach (var obj in currentObjects[x, y])
                    //{
                    //    obj.SwitchCurrentAndSavedState();
                    //}
                    //foreach (var player in currentPlayers[x, y])
                    //{
                    //    player.SwitchCurrentAndSavedState();
                    //}
                }

            try
            {
                consolidationOfNewObjects = true;
                while (ConsolidateNewObjectsAndPlayers()) { }
            }
            finally
            {
                consolidationOfNewObjects = false;
            }

            CheckPositionsConsistency();

            Utils.Exchange(ref currentObjects, ref newObjects);
            Utils.Exchange(ref currentPlayers, ref newPlayers);
        }

        [Conditional("DEBUG")]
        private void CheckPositionsConsistency()
        {
            for (int y = 0; y < Height; y++)
                for (int x = 0; x < Width; x++)
                {
                    Debug.Assert(newObjects[x, y].All(o => o.Position == new Position(x, y)));
                    Debug.Assert(newPlayers[x, y].All(o => o.Position == new Position(x, y)));
                }
        }

        /// <summary>
        /// Handles interaction between objects.
        /// </summary>
        /// <returns>Returns true if consolidation should run again (for example beacause of newly generated objects).</returns>
        public abstract bool ConsolidateNewObjectsAndPlayers();

        public void AddObject(GameObject<PlayerType, PlayerActionType, PlayerStateType> obj)
            => (initialized ? newObjects : currentObjects)[obj.Position.X, obj.Position.Y].Add(obj);

        public void RemoveObject(GameObject<PlayerType, PlayerActionType, PlayerStateType> obj)
            => (initialized ? newObjects : currentObjects)[obj.Position.X, obj.Position.Y].Remove(obj);

        protected void AddPlayer(PlayerType player)
            => (initialized & consolidationOfNewObjects ? newPlayers : currentPlayers)[player.Position.X, player.Position.Y].Add(player);

        protected void MoveObject(GameObject<PlayerType, PlayerActionType, PlayerStateType> obj, Position from, Position to)
        {
            if (obj is PlayerType player)
            {
                (initialized ? newPlayers : currentPlayers)[from.X, from.Y].Remove(player);
                (initialized ? newPlayers : currentPlayers)[to.X, to.Y].Add(player);
                Debug.Assert(player.Position == from);
                player.Position = to;
            }
            else
            {
                (initialized ? newObjects : currentObjects)[from.X, from.Y].Remove(obj);
                (initialized ? newObjects : currentObjects)[to.X, to.Y].Add(obj);
                Debug.Assert(obj.Position == from);
                obj.Position = to;
            }
        }

        protected abstract void ProcessPlayerAction(PlayerType player, PlayerActionType action);

        public void PlayerDied(PlayerType player)
        {
            //TODO
        }

        public delegate PlayerType CreatePlayerHandler(PlayerDefinition playerDefinition, string teamName);
    }
}