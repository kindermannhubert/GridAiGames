﻿using System.Collections.Generic;

namespace GridAiGames
{
    public interface IReadOnlyGameGrid<PlayerType, PlayerActionType, PlayerStateType>
        where PlayerType : Player<PlayerType, PlayerActionType, PlayerStateType>
        where PlayerStateType : struct, IGameObjectState<PlayerStateType>
    {
        int Width { get; }
        int Height { get; }

        IEnumerable<GameObject<PlayerType, PlayerActionType, PlayerStateType>> AllObjects { get; }
        IEnumerable<PlayerType> AllPlayers { get; }

        IReadOnlyList<GameObject<PlayerType, PlayerActionType, PlayerStateType>> GetObjects(int x, int y);
        IReadOnlyList<PlayerType> GetPlayers(int x, int y);
    }

    public static class IReadOnlyGameGridX
    {
        public static IReadOnlyList<GameObject<PlayerType, PlayerActionType, PlayerStateType>> GetObjects<PlayerType, PlayerActionType, PlayerStateType>(this IReadOnlyGameGrid<PlayerType, PlayerActionType, PlayerStateType> grid, Position position)
            where PlayerType : Player<PlayerType, PlayerActionType, PlayerStateType>
            where PlayerStateType : struct, IGameObjectState<PlayerStateType>
            => grid.GetObjects(position.X, position.Y);

        public static IReadOnlyList<GameObject<PlayerType, PlayerActionType, PlayerStateType>> GetPlayers<PlayerType, PlayerActionType, PlayerStateType>(this IReadOnlyGameGrid<PlayerType, PlayerActionType, PlayerStateType> grid, Position position)
            where PlayerType : Player<PlayerType, PlayerActionType, PlayerStateType>
            where PlayerStateType : struct, IGameObjectState<PlayerStateType>
            => grid.GetObjects(position.X, position.Y);
    }
}