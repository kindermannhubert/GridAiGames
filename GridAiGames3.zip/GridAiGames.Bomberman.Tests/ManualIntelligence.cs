﻿using System.Collections.Generic;
using System.Linq;

namespace GridAiGames.Bomberman.Tests
{
    internal class ManualIntelligence : IIntelligence<Player, PlayerAction, PlayerState>
    {
        private readonly Dictionary<Player, PlayerAction> nextActions = new Dictionary<Player, PlayerAction>();

        public IEnumerable<(Player player, PlayerAction action)>
            GetActionForTeam(
                IReadOnlyGameGrid<Player, PlayerAction, PlayerState> gameGrid,
                IReadOnlyList<Player> teamPlayers,
                ulong iteration)
        {
            foreach (var player in teamPlayers)
            {
                if (nextActions.ContainsKey(player))
                {
                    yield return (player, nextActions[player]);
                }
                else
                {
                    yield return (player, PlayerAction.None);
                }
            }
            nextActions.Clear();
        }

        public void SetNextActions(
            IReadOnlyGameGrid<Player, PlayerAction, PlayerState> gameGrid,
            params (string playerName, PlayerAction action)[] actions)
        {
            foreach (var item in actions)
            {
                var player = gameGrid.AllPlayers.Single(p => p.Name == item.playerName);
                nextActions.Add(player, item.action);
            }
        }
    }
}
