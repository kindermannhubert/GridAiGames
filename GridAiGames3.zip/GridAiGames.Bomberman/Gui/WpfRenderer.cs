﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace GridAiGames.Bomberman.Gui
{
    internal class WpfRenderer
    {
        private readonly GameGrid grid;
        private readonly Pen pen = new Pen(Brushes.Black, 1);
        private readonly ImageSource bombImage;
        private readonly ImageSource fire1Image, fire2Image;
        private readonly ImageSource playerFrontImage, playerRightImage, playerBackImage;
        private readonly Dictionary<Player, Position> lastDistinctPositionPerPlayer = new Dictionary<Player, Position>();

        public WpfRenderer(GameGrid grid)
        {
            this.grid = grid;
            pen.Freeze();

            bombImage = LoadResourceImage("Bomb.png");
            fire1Image = LoadResourceImage("Fire1.png");
            fire2Image = LoadResourceImage("Fire2.png");
            playerFrontImage = LoadResourceImage("PlayerFront.png");
            playerRightImage = LoadResourceImage("PlayerRight.png");
            playerBackImage = LoadResourceImage("PlayerBack.png");
        }

        public void Render(DrawingContext context, double width, double height, double gameIteration)
        {
            var scale = width / grid.Width < height / grid.Height ? width / grid.Width : height / grid.Height;
            var cellSize = scale;

            context.PushTransform(new ScaleTransform(1, -1));
            context.PushTransform(new TranslateTransform(0, -height));
            context.DrawRectangle(Brushes.WhiteSmoke, null, new Rect(0, 0, width, height));
            for (int y = 0; y < grid.Height; y++)
            {
                for (int x = 0; x < grid.Width; x++)
                {
                    var cellRectangle = new Rect(x * scale, y * scale, cellSize, cellSize);

                    foreach (var obj in grid.GetObjects(x, y))
                    {
                        Brush brush;

                        switch (obj)
                        {
                            case Wall w:
                                if (w.IsDestroyable) brush = Brushes.LightGray;
                                else brush = Brushes.Gray;
                                context.DrawRectangle(brush, pen, cellRectangle);
                                break;
                            case Bomb _:
                                brush = Brushes.Red;

                                context.PushTransform(new TranslateTransform(x * scale + 0.5 * cellSize, y * scale + 0.5 * cellSize));

                                var scaleBomb = gameIteration % 2 == 0 ? (0.8 + 0.2 * (gameIteration - (int)gameIteration)) : (0.8 + 0.2 * (1 - gameIteration + (int)gameIteration));
                                context.PushTransform(new ScaleTransform(scaleBomb, scaleBomb));
                                DrawImage(context, bombImage, new Rect(-0.5 * cellSize, -0.5 * cellSize, cellSize, cellSize));
                                context.Pop();
                                context.Pop();
                                //context.DrawImage(bombImage, cellRectangle);
                                break;
                            case BombDetonationFire f:
                                brush = Brushes.Orange;
                                //context.DrawRectangle(brush, pen, cellRectangle);

                                switch (f.Type)
                                {
                                    case BombDetonationFireType.Horizontal:
                                        DrawImage(context, x % 2 == 0 ? fire1Image : fire2Image, cellRectangle);
                                        break;
                                    case BombDetonationFireType.Vertical:
                                        context.PushTransform(new TranslateTransform(x * scale + 0.5 * cellSize, y * scale + 0.5 * cellSize));
                                        context.PushTransform(new RotateTransform(90));
                                        DrawImage(context, y % 2 == 0 ? fire1Image : fire2Image, new Rect(-0.5 * cellSize, -0.5 * cellSize, cellSize, cellSize));
                                        context.Pop();
                                        context.Pop();
                                        break;
                                    case BombDetonationFireType.Center:
                                        DrawImage(context, x % 2 == 0 ? fire1Image : fire2Image, cellRectangle);

                                        context.PushTransform(new TranslateTransform(x * scale + 0.5 * cellSize, y * scale + 0.5 * cellSize));
                                        context.PushTransform(new RotateTransform(90));
                                        DrawImage(context, y % 2 == 0 ? fire1Image : fire2Image, new Rect(-0.5 * cellSize, -0.5 * cellSize, cellSize, cellSize));
                                        context.Pop();
                                        context.Pop();
                                        break;
                                    default:
                                        throw new InvalidOperationException($"Unknown fire type: '{f.Type}'.");
                                }
                                break;
                            case Bonus b:
                                if (!grid.GetObjects(x, y).Any(o => o is BombDetonationFire))
                                {
                                    switch (b.Type)
                                    {
                                        case BonusType.Bomb:
                                            context.DrawRectangle(Brushes.Black, pen, cellRectangle);
                                            break;
                                        case BonusType.Fire:
                                            context.DrawRectangle(Brushes.Gold, pen, cellRectangle);
                                            break;
                                        default:
                                            throw new InvalidOperationException($"Unknown bonus type: '{b.Type}'.");
                                    }
                                }
                                break;
                            default:
                                throw new InvalidOperationException($"Unknown object type: '{obj.GetType().FullName}'.");
                        }
                    }
                }
            }

            for (int y = 0; y < grid.Height; y++)
            {
                for (int x = 0; x < grid.Width; x++)
                {
                    foreach (var player in grid.GetPlayers(x, y))
                    {
                        if (!lastDistinctPositionPerPlayer.TryGetValue(player, out var lastDistinctPosition))
                        {
                            lastDistinctPositionPerPlayer.Add(player, lastDistinctPosition = player.Position);
                        }
                        if (player.Position != player.PreviousPosition) lastDistinctPositionPerPlayer[player] = player.PreviousPosition;

                        var t = gameIteration - (int)gameIteration;

                        var renderX = scale * (t * x + (1 - t) * player.PreviousPosition.X);
                        var renderY = scale * (t * y + (1 - t) * player.PreviousPosition.Y);

                        var posDelta = player.Position - lastDistinctPosition;
                        TransformGroup imageTransform = null;
                        ImageSource image = playerFrontImage;
                        if (posDelta.X > 0)
                        {
                            image = playerRightImage;
                        }
                        else if (posDelta.X < 0)
                        {
                            image = playerRightImage;
                            imageTransform = new TransformGroup();
                            imageTransform.Children.Add(new TranslateTransform(-cellSize, 0));
                            imageTransform.Children.Add(new ScaleTransform(-1, 1));
                        }
                        else if (posDelta.Y > 0)
                        {
                            image = playerBackImage;
                        }
                        else if (posDelta.Y < 0)
                        {
                            image = playerFrontImage;
                        }

                        DrawImage(context, image, new Rect(renderX, renderY, cellSize, 1.5 * cellSize), imageTransform);
                        break;
                    }
                }
            }

            context.Pop();
            context.Pop();
        }

        private static void DrawImage(DrawingContext context, ImageSource image, Rect rectangle, Transform imageTransform = null)
        {
            context.PushTransform(new TranslateTransform(rectangle.X, rectangle.Y + rectangle.Height));
            context.PushTransform(new ScaleTransform(1, -1));
            if (imageTransform != null) context.PushTransform(imageTransform);
            rectangle.X = 0;
            rectangle.Y = 0;
            context.DrawImage(image, rectangle);
            if (imageTransform != null) context.Pop();
            context.Pop();
            context.Pop();
        }

        private static ImageSource LoadResourceImage(string name)
        {
            var uri = new Uri($"pack://application:,,,/{Assembly.GetExecutingAssembly().GetName().Name};component/Gui/Resources/{name}", UriKind.RelativeOrAbsolute);
            var img = BitmapFrame.Create(uri);
            img.Freeze();
            return img;
        }
    }
}