﻿namespace GridAiGames.Bomberman
{
    internal class Bonus : GameObject<Player, PlayerAction, PlayerState, BonusState>
    {
        public BonusType Type { get; }

        public Bonus(Position position, BonusType type)
            : base(position)
        {
            Type = type;
        }

        public override void Update(IGameGrid<Player, PlayerAction, PlayerState> gameGrid, ulong iteration)
        {
        }
    }

    internal struct BonusState : IGameObjectState<BonusState>
    {
        public Position Position { get; set; }
    }

    public enum BonusType
    {
        Bomb,
        Fire,

        _MaxValue = Fire
    }
}
