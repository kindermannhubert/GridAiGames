﻿using System;
using System.Collections.Generic;

namespace GridAiGames.Bomberman
{
    internal class Intelligence : IIntelligence<Player, PlayerAction, PlayerState>
    {
        private static readonly Random rand = new Random(3);

        public IEnumerable<(Player player, PlayerAction action)>
            GetActionForTeam(
                IReadOnlyGameGrid<Player, PlayerAction, PlayerState> gameGrid,
                IReadOnlyList<Player> teamPlayers,
                ulong iteration)
        {
            foreach (var player in teamPlayers)
            {
                //if (iteration % 2 == 0) yield return (player, PlayerAction.MoveRight);
                //else yield return (player, PlayerAction.MoveUp);

                yield return (player, (PlayerAction)rand.Next(1, 6));

                //yield return (player, PlayerAction.MoveRight);
            }
        }
    }
}
