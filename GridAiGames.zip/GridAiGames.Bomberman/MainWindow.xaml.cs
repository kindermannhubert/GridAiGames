﻿using System;
using System.ComponentModel;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using GridAiGames.Bomberman.Gui;

namespace GridAiGames.Bomberman
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private readonly WpfRenderer wpfRenderer;
        private readonly Thread backgroundThread;
        private double gameIteration;
        private bool cancelGame;

        public MainWindow()
        {
            InitializeComponent();

            var grid = new GameGrid(
                32, 32,
                new TeamDefinition<PlayerAction>[]
                {
                    new TeamDefinition<PlayerAction>("Team A", new[] { new PlayerDefinition("Hubert"), new PlayerDefinition("Petr") }, new Intelligence()),
                    new TeamDefinition<PlayerAction>("Team B", new[] { new PlayerDefinition("Lojza"), new PlayerDefinition("Adam") }, new Intelligence())
                },
                new Random(1));

            //var consoleRenderer = new ConsoleRenderer(grid);
            wpfRenderer = new WpfRenderer(grid);

            backgroundThread = new Thread(() =>
                {
                    ulong iteration = 0;
                    const double UpdatingIntervalMs = 300;
                    const int RenderFramesBetweenUpdate = 10;

                    while (!cancelGame)
                    {
                        grid.Update(iteration);

                        var currentTeamsCount = grid.AllPlayers.Select(p => p.TeamName).Distinct().Count();
                        if (currentTeamsCount < 2)
                        {
                            if (currentTeamsCount == 0)
                            {
                                Console.WriteLine("Nobody wins.");
                                break;
                            }
                            if (currentTeamsCount == 1)
                            {
                                Console.WriteLine($"Team '{grid.AllPlayers}' won.");
                                break;
                            }
                        }

                        gameIteration = iteration;
                        for (int i = 0; i < RenderFramesBetweenUpdate; i++)
                        {
                            gameIteration = iteration + (double)i / RenderFramesBetweenUpdate;
                            //consoleRenderer.Render();
                            try
                            {
                                Dispatcher.Invoke(InvalidateVisual);
                            }
                            catch (TaskCanceledException)
                            {
                                break;
                            }
                            Thread.Sleep(TimeSpan.FromMilliseconds(UpdatingIntervalMs / RenderFramesBetweenUpdate));
                        }

                        iteration++;
                    }
                });
            backgroundThread.Start();
        }

        protected override void OnRender(DrawingContext drawingContext)
        {
            base.OnRender(drawingContext);
            wpfRenderer.Render(drawingContext, ((Panel)Content).ActualWidth, ((Panel)Content).ActualHeight, gameIteration);
        }

        protected override void OnClosing(CancelEventArgs e)
        {
            cancelGame = true;
            backgroundThread.Join(500);

            base.OnClosing(e);
        }
    }
}
