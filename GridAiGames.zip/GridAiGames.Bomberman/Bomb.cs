﻿using System;
using System.Linq;

namespace GridAiGames.Bomberman
{
    internal class Bomb : IGameObject<PlayerAction>
    {
        private readonly int radius;
        private Position position;
        private int DetonateAfter;

        public Position Position => position;

        public Bomb(Position position, int radius)
        {
            DetonateAfter = 10;
            this.position = position;
            this.radius = radius;
        }

        public void Update(IGameGrid<PlayerAction> gameGrid, Position position, ulong iteration)
        {
            this.position = position;

            if (--DetonateAfter == 0)
            {
                Detonate(gameGrid);
            }
        }

        public void Detonate(IGameGrid<PlayerAction> gameGrid)
        {
            gameGrid.RemoveObject(this, position);
            gameGrid.AddObject(new BombDetonationFire(BombDetonationFireType.Center), position);

            FillOneDirectionWithFire(gameGrid, position, new Position(-1, 0));
            FillOneDirectionWithFire(gameGrid, position, new Position(0, 1));
            FillOneDirectionWithFire(gameGrid, position, new Position(1, 0));
            FillOneDirectionWithFire(gameGrid, position, new Position(0, -1));
        }

        private Position FillOneDirectionWithFire(IGameGrid<PlayerAction> gameGrid, Position currentPos, Position delta)
        {
            for (int r = 0; r < radius; r++)
            {
                currentPos += delta;
                if (IsPositionAvailableForFire(gameGrid, currentPos))
                {
                    gameGrid.AddObject(new BombDetonationFire(delta.Y == 0 ? BombDetonationFireType.Horizontal : BombDetonationFireType.Vertical), currentPos);

                    if (gameGrid.GetObjects(currentPos).Any(o => o is Wall)) break; //stop spreading fire after hit of first destoyable wall
                }
                else break;
            }

            return currentPos;
        }

        private bool IsPositionAvailableForFire(IGameGrid<PlayerAction> gameGrid, Position position)
        {
            foreach (var obj in gameGrid.GetObjects(position))
            {
                switch (obj)
                {
                    case Wall w:
                        return w.IsDestroyable;
                    case Bomb _:
                    case BombDetonationFire _:
                    case Bonus _:
                        return true;
                    default:
                        throw new InvalidOperationException($"Unknown object type: '{obj.GetType().FullName}'.");
                }
            }
            return true;
        }
    }
}
