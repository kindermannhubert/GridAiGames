﻿namespace GridAiGames.Bomberman
{
    internal class BombDetonationFire : IGameObject<PlayerAction>
    {
        private Position position;
        private int DisappearAfter;
        private bool isBurning;

        public Position Position => position;
        public bool IsBurning => isBurning;
        public BombDetonationFireType Type { get; }

        public BombDetonationFire(BombDetonationFireType type)
        {
            DisappearAfter = 2;
            isBurning = true;
            Type = type;
        }

        public void Update(IGameGrid<PlayerAction> gameGrid, Position position, ulong iteration)
        {
            this.position = position;
            isBurning = false;

            if (--DisappearAfter == 0)
            {
                gameGrid.RemoveObject(this, position);
            }
        }
    }

    internal enum BombDetonationFireType
    {
        Horizontal,
        Vertical,
        Center
    }
}
