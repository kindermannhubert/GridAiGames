﻿namespace GridAiGames.Bomberman
{
    internal class Bonus : IGameObject<PlayerAction>
    {
        public BonusType Type { get; }
        public Position Position { get; private set; }

        public Bonus(Position position, BonusType type)
        {
            Position = position;
            Type = type;
        }

        public void Update(IGameGrid<PlayerAction> gameGrid, Position position, ulong iteration)
        {
            Position = position;
        }

    }

    public enum BonusType
    {
        Bomb,
        Fire,

        _MaxValue = Fire
    }
}
