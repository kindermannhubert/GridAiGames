﻿using System;

namespace GridAiGames.Bomberman
{
    [Flags]
    public enum PlayerAction
    {
        MoveLeft,
        MoveUp,
        MoveRight,
        MoveDown,
        PlaceBomb
    }
}
