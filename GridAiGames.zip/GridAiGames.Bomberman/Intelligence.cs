﻿using System;
using System.Collections.Generic;

namespace GridAiGames.Bomberman
{
    public class Intelligence : IIntelligence<PlayerAction>
    {
        private static readonly Random rand = new Random(3);

        public IEnumerable<(Player<PlayerAction> player, PlayerAction action)>
            GetActionForTeam(
                IReadOnlyGameGrid<PlayerAction> gameGrid,
                IReadOnlyList<Player<PlayerAction>> teamPlayers,
                ulong iteration)
        {
            foreach (var player in teamPlayers)
            {
                //if (iteration % 2 == 0) yield return (player, PlayerAction.MoveRight);
                //else yield return (player, PlayerAction.MoveUp);

                yield return (player, (PlayerAction)rand.Next(5));
            }
        }
    }
}
