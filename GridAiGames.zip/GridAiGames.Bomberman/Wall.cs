﻿namespace GridAiGames.Bomberman
{
    internal class Wall : IGameObject<PlayerAction>
    {
        private Position position;

        public Position Position => position;
        public bool IsDestroyable { get; }

        public Wall(Position position, bool isDestroyable = false)
        {
            this.position = position;
            this.IsDestroyable = isDestroyable;
        }

        public void Update(IGameGrid<PlayerAction> gameGrid, Position position, ulong iteration)
        {
            this.position = position;
        }
    }
}