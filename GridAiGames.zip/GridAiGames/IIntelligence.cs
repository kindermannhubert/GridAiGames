﻿using System.Collections.Generic;

namespace GridAiGames
{
    public interface IIntelligence<PlayerType, PlayerActionType>
        where PlayerType : Player<PlayerActionType>
    {
        IEnumerable<(PlayerType player, PlayerActionType action)>
            GetActionForTeam(
            IReadOnlyGameGrid<PlayerType, PlayerActionType> gameGrid,
            IReadOnlyList<Player<PlayerActionType>> teamPlayers,
            ulong iteration);
    }
}