﻿namespace GridAiGames
{
    public interface IGameGrid<PlayerType, PlayerActionType> : IReadOnlyGameGrid<PlayerType, PlayerActionType>
        where PlayerType : Player<PlayerActionType>
    {
        void AddObject(IGameObject<PlayerType, PlayerActionType> obj, int x, int y);
        void RemoveObject(IGameObject<PlayerType, PlayerActionType> obj, int x, int y);
        void PlayerDied(PlayerType player);
    }

    public static class IGameGridX
    {
        public static void AddObject<PlayerType, PlayerActionType>(this IGameGrid<PlayerType, PlayerActionType> grid, IGameObject<PlayerType, PlayerActionType> obj, Position position)
            where PlayerType : Player<PlayerActionType>
            => grid.AddObject(obj, position.X, position.Y);

        public static void RemoveObject<PlayerType, PlayerActionType>(this IGameGrid<PlayerType, PlayerActionType> grid, IGameObject<PlayerType, PlayerActionType> obj, Position position)
            where PlayerType : Player<PlayerActionType>
            => grid.RemoveObject(obj, position.X, position.Y);
    }
}