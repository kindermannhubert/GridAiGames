﻿namespace GridAiGames
{
    public interface IGameObject<PlayerType, PlayerActionType>
        where PlayerType : Player<PlayerActionType>
    {
        Position Position { get; }
        void Update(IGameGrid<PlayerType, PlayerActionType> gameGrid, Position position, ulong iteration);
    }
}