﻿using System.Collections.Generic;

namespace GridAiGames
{
    public class TeamDefinition<PlayerType, PlayerActionType>
        where PlayerType : Player<PlayerActionType>
    {
        public string Name { get; }
        public IReadOnlyList<PlayerDefinition> Players { get; }
        public IIntelligence<PlayerType, PlayerActionType> Intelligence { get; }

        public TeamDefinition(string name, IReadOnlyList<PlayerDefinition> players, IIntelligence<PlayerType, PlayerActionType> intelligence)
        {
            Name = name;
            Players = players;
            Intelligence = intelligence;
        }
    }
}