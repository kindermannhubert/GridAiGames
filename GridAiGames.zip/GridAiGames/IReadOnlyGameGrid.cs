﻿using System.Collections.Generic;

namespace GridAiGames
{
    public interface IReadOnlyGameGrid<PlayerType, PlayerActionType>
        where PlayerType : Player<PlayerActionType>
    {
        int Width { get; }
        int Height { get; }

        IEnumerable<IGameObject<PlayerType, PlayerActionType>> AllObjects { get; }
        IEnumerable<PlayerType> AllPlayers { get; }

        IReadOnlyList<IGameObject<PlayerType, PlayerActionType>> GetObjects(int x, int y);
        IReadOnlyList<PlayerType> GetPlayers(int x, int y);
    }

    public static class IReadOnlyGameGridX
    {
        public static IReadOnlyList<IGameObject<PlayerType, PlayerActionType>> GetObjects<PlayerType, PlayerActionType>(this IReadOnlyGameGrid<PlayerType, PlayerActionType> grid, Position position)
            where PlayerType : Player<PlayerActionType>
            => grid.GetObjects(position.X, position.Y);

        public static IReadOnlyList<IGameObject<PlayerType, PlayerActionType>> GetPlayers<PlayerType, PlayerActionType>(this IReadOnlyGameGrid<PlayerType, PlayerActionType> grid, Position position)
            where PlayerType : Player<PlayerActionType>
            => grid.GetObjects(position.X, position.Y);
    }
}