﻿namespace GridAiGames
{
    public abstract class Player<PlayerActionType> : IGameObject<Player<PlayerActionType>, PlayerActionType>
    {
        private Position position;
        private Position previousPosition;
        private bool isDead;

        public Position Position => position;
        public Position PreviousPosition => previousPosition;
        public string Name { get; }
        public string TeamName { get; }

        protected Player(string name, string teamName, Position position)
        {
            Name = name;
            TeamName = teamName;
            this.position = previousPosition = position;
        }

        public virtual void Update(IGameGrid<Player<PlayerActionType>, PlayerActionType> gameGrid, Position position, ulong iteration)
        {
            previousPosition = this.position;
            this.position = position;

            if (isDead) gameGrid.PlayerDied(this);
        }

        public void Kill()
        {
            isDead = true;
        }
    }
}