﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace GridAiGames
{
    public abstract class GameGrid<PlayerType, PlayerActionType> : IGameGrid<PlayerType, PlayerActionType>
        where PlayerType : Player<PlayerActionType>
    {
        private readonly IReadOnlyList<TeamDefinition<PlayerType, PlayerActionType>> teamDefinitions;
        private readonly Dictionary<string, List<PlayerType>> playersPerTeamName = new Dictionary<string, List<PlayerType>>();

        private List<IGameObject<PlayerType, PlayerActionType>>[,] currentObjects;
        private List<PlayerType>[,] currentPlayers;

        private List<IGameObject<PlayerType, PlayerActionType>>[,] newObjects;
        private List<PlayerType>[,] newPlayers;

        private bool consolidationOfNewObjects;
        protected bool initialized;

        public IEnumerable<IGameObject<PlayerType, PlayerActionType>> AllObjects
        {
            get
            {
                for (int y = 0; y < Height; y++)
                    for (int x = 0; x < Width; x++)
                        foreach (var obj in (initialized | consolidationOfNewObjects ? newObjects : currentObjects)[x, y])
                        {
                            yield return obj;
                        }
            }
        }

        public IEnumerable<PlayerType> AllPlayers
        {
            get
            {
                for (int y = 0; y < Height; y++)
                    for (int x = 0; x < Width; x++)
                        foreach (var p in (initialized | consolidationOfNewObjects ? newPlayers : currentPlayers)[x, y])
                        {
                            yield return p;
                        }
            }
        }

        public IReadOnlyList<IGameObject<PlayerType, PlayerActionType>> GetObjects(int x, int y) => (initialized | consolidationOfNewObjects ? newObjects : currentObjects)[x, y];
        public IReadOnlyList<IGameObject<PlayerType, PlayerActionType>> GetObjects(Position position) => (initialized | consolidationOfNewObjects ? newObjects : currentObjects)[position.X, position.Y];

        public IReadOnlyList<PlayerType> GetPlayers(int x, int y) => (initialized | consolidationOfNewObjects ? newPlayers : currentPlayers)[x, y];
        public IReadOnlyList<PlayerType> GetPlayers(Position position) => (initialized | consolidationOfNewObjects ? newPlayers : currentPlayers)[position.X, position.Y];

        public int Width { get; }
        public int Height { get; }

        public GameGrid(
            int width,
            int height,
            IReadOnlyList<TeamDefinition<PlayerType, PlayerActionType>> teamDefinitions,
            CreatePlayerHandler createPlayer)
        {
            Width = width;
            Height = height;
            this.teamDefinitions = teamDefinitions;

            currentObjects = new List<IGameObject<PlayerType, PlayerActionType>>[width, height];
            newObjects = new List<IGameObject<PlayerType, PlayerActionType>>[width, height];
            currentPlayers = new List<PlayerType>[width, height];
            newPlayers = new List<PlayerType>[width, height];
            for (int y = 0; y < Height; y++)
                for (int x = 0; x < Width; x++)
                {
                    currentObjects[x, y] = new List<IGameObject<PlayerType, PlayerActionType>>();
                    newObjects[x, y] = new List<IGameObject<PlayerType, PlayerActionType>>();
                    currentPlayers[x, y] = new List<PlayerType>();
                    newPlayers[x, y] = new List<PlayerType>();
                }

            if (teamDefinitions.Select(t => t.Name).Distinct().Count() != teamDefinitions.Count)
                throw new InvalidOperationException("All team names must be distinct.");

            foreach (var teamDefinition in teamDefinitions)
            {
                if (teamDefinition.Players.Select(p => p.Name).Distinct().Count() != teamDefinition.Players.Count)
                    throw new InvalidOperationException("All player names must be distinct.");

                foreach (var playerDefinition in teamDefinition.Players)
                {
                    var (player, position) = createPlayer(playerDefinition, teamDefinition.Name);
                    AddPlayer(player, position.X, position.Y);

                    if (!playersPerTeamName.TryGetValue(teamDefinition.Name, out var teamPlayers))
                    {
                        playersPerTeamName.Add(teamDefinition.Name, teamPlayers = new List<PlayerType>());
                    }
                    teamPlayers.Add(player);
                }
            }
        }

        public virtual void Update(ulong iteration)
        {
            if (!initialized) throw new InvalidOperationException("Grid should not be updated until its initialized flag is set to true.");

            for (int y = 0; y < Height; y++)
                for (int x = 0; x < Width; x++)
                {
                    newObjects[x, y].Clear();
                    newObjects[x, y].AddRange(currentObjects[x, y]);

                    newPlayers[x, y].Clear();
                    newPlayers[x, y].AddRange(currentPlayers[x, y]);
                }

            for (int y = 0; y < Height; y++)
                for (int x = 0; x < Width; x++)
                {
                    foreach (var obj in currentObjects[x, y])
                    {
                        //objects is allowed to change their position in their update method
                        var positionBeforeUpdate = new Position(x, y);
                        obj.Update(this, positionBeforeUpdate, iteration);
                        if (positionBeforeUpdate != obj.Position) MoveObject(obj, positionBeforeUpdate, obj.Position);
                    }

                    foreach (var player in currentPlayers[x, y])
                    {
                        var positionBeforeUpdate = new Position(x, y);
                        player.Update(this, positionBeforeUpdate, iteration);
                        if (positionBeforeUpdate != player.Position) throw new InvalidOperationException("Player's position can be changed only by IIntelligence actions.");
                    }
                }

            foreach (var team in teamDefinitions)
            {
                var teamActions = team.Intelligence.GetActionForTeam(this, playersPerTeamName[team.Name], iteration);
                foreach (var (player, action) in teamActions)
                {
                    ProcessPlayerAction(player, action);
                }
            }

            try
            {
                consolidationOfNewObjects = true;
                while (ConsolidateNewObjectsAndPlayers()) { }
            }
            finally
            {
                consolidationOfNewObjects = false;
            }

            Utils.Exchange(ref currentObjects, ref newObjects);
            Utils.Exchange(ref currentPlayers, ref newPlayers);
        }

        /// <summary>
        /// Handles interaction between objects.
        /// </summary>
        /// <returns>Returns true if consolidation should run again (for example beacause of newly generated objects).</returns>
        public abstract bool ConsolidateNewObjectsAndPlayers();

        public void AddObject(IGameObject<PlayerType, PlayerActionType> obj, int x, int y)
            => (initialized | consolidationOfNewObjects ? newObjects : currentObjects)[x, y].Add(obj);

        public void RemoveObject(IGameObject<PlayerType, PlayerActionType> obj, int x, int y)
            => (initialized | consolidationOfNewObjects ? newObjects : currentObjects)[x, y].Remove(obj);

        protected void AddPlayer(PlayerType player, int x, int y)
            => (initialized | consolidationOfNewObjects ? newPlayers : currentPlayers)[x, y].Add(player);

        protected void MoveObject(IGameObject<PlayerType, PlayerActionType> obj, Position from, Position to)
        {
            if (obj is PlayerType player)
            {
                (initialized | consolidationOfNewObjects ? newPlayers : currentPlayers)[from.X, from.Y].Remove(player);
                (initialized | consolidationOfNewObjects ? newPlayers : currentPlayers)[to.X, to.Y].Add(player);
            }
            else
            {
                (initialized | consolidationOfNewObjects ? newObjects : currentObjects)[from.X, from.Y].Remove(obj);
                (initialized | consolidationOfNewObjects ? newObjects : currentObjects)[to.X, to.Y].Add(obj);
            }
        }

        protected abstract void ProcessPlayerAction(PlayerType player, PlayerActionType action);

        public void PlayerDied(PlayerType player)
        {
            //TODO
        }

        public delegate (PlayerType, Position) CreatePlayerHandler(PlayerDefinition playerDefinition, string teamName);
    }
}